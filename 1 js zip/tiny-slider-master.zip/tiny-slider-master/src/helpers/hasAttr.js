export function hasAttr(el, attr) {
  return el.hasAttribute(attr);
}